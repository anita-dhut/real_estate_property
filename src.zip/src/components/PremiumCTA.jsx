import Button from './Button';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { ArrowRight } from 'lucide-react';
import './PremiumCTA.css';

export default function PremiumCTA() {
  const [ref, isVisible] = useIntersectionObserver({ threshold: 0.2 });

  return (
    <section className="premium-cta-section" ref={ref}>
      <div className="premium-cta-bg parallax-bg">
        <img src="https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?q=80&w=2070&auto=format&fit=crop" alt="Premium architecture" loading="lazy" />
        <div className="premium-cta-overlay"></div>
      </div>
      
      <div className={`premium-cta-content page-container fade-up ${isVisible ? 'is-visible' : ''}`}>
        <div className="cta-inner text-center">
          <h2 className="cta-heading-large">
            LET'S TALK ABOUT<br/>
            YOUR NEXT ADDRESS.
          </h2>
          <p className="cta-description">
            Whether you're looking for a new home or exploring redevelopment opportunities, we'd love to hear from you.
          </p>
          <div className="cta-actions justify-center mt-8">
            <Button to="/contact" variant="primary">
              Start a Conversation <ArrowRight size={18} className="ml-2 inline" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
