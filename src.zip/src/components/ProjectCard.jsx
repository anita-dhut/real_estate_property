import { Link } from 'react-router-dom';
import { ArrowRight, MapPin } from 'lucide-react';
import './ProjectCard.css';

export default function ProjectCard({ project }) {
  return (
    <Link to={`/projects/${project.slug}`} className="project-card fade-up">
      <div className="project-img-wrapper">
        <img src={project.image || project.heroImage} alt={project.title || project.name} loading="lazy" />
        <div className="project-status">{project.status}</div>
        <div className="project-hover-overlay">
          <span className="view-project-text">View Project <ArrowRight size={18} /></span>
        </div>
      </div>
      
      <div className="project-content">
        <h3>{project.title || project.name}</h3>
        <div className="project-meta">
          <span className="location"><MapPin size={16} /> {project.location}</span>
          <span className="bhk">{project.bhk}</span>
        </div>
      </div>
    </Link>
  );
}
