import { Search, X } from 'lucide-react';
import { allProjects } from '../data/projects';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import './ProjectFilter.css';

export default function ProjectFilter({
  activeStatus, setActiveStatus,
  activeLocation, setActiveLocation,
  activeBHK, setActiveBHK,
  searchQuery, setSearchQuery,
  totalResults,
  resetFilters
}) {
  const [ref, isVisible] = useIntersectionObserver({ threshold: 0.1 });

  const statuses = ['All', 'Under Construction', 'Completed', 'Sold Out'];
  const locations = ['All Locations', ...new Set(allProjects.map(p => p.location))];
  const bhks = ['All Configurations', '2 BHK', '2.5 BHK', '3 BHK', '4 BHK', '4.5 BHK'];

  return (
    <div className={`project-filter-container fade-up ${isVisible ? 'is-visible' : ''}`} ref={ref}>
      <div className="project-filter">
        <div className="filter-group search-group">
          <label>Search Projects</label>
          <div className="search-input-wrapper">
            <Search size={18} className="search-icon" />
            <input 
              type="text" 
              placeholder="Search by name, location..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        <div className="filter-group">
          <label>Status</label>
          <select value={activeStatus} onChange={(e) => setActiveStatus(e.target.value)}>
            {statuses.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
        
        <div className="filter-group">
          <label>Location</label>
          <select value={activeLocation} onChange={(e) => setActiveLocation(e.target.value)}>
            {locations.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>

        <div className="filter-group">
          <label>Configuration</label>
          <select value={activeBHK} onChange={(e) => setActiveBHK(e.target.value)}>
            {bhks.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
      </div>
      
      <div className="filter-footer">
        <span className="results-count">{totalResults} Project{totalResults !== 1 ? 's' : ''} Found</span>
        <button onClick={resetFilters} className="clear-filters-btn">
          <X size={16} /> Clear Filters
        </button>
      </div>
    </div>
  );
}
