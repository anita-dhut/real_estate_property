import { MessageCircle, Phone, Mail } from 'lucide-react';
import { contactInfo } from '../data/contact';
import './FloatingCTA.css';

export default function FloatingCTA() {
  return (
    <>
      {/* Desktop Floating Button */}
      <a href="mailto:sales@Nivara Developers.com" className="floating-cta-desktop" aria-label="Enquire Now">
        <MessageCircle size={20} />
        <span>Enquire Now</span>
      </a>

      {/* Mobile Fixed Bottom Bar */}
      <div className="floating-cta-mobile">
        <a href={`tel:${contactInfo.phone.replace(/[^0-9+]/g, '')}`} className="mobile-cta-action" aria-label="Call Us">
          <Phone size={20} />
          <span>Call</span>
        </a>
        <a href={`https://wa.me/91${contactInfo.phone.replace(/[^0-9]/g, '')}`} target="_blank" rel="noopener noreferrer" className="mobile-cta-action whatsapp" aria-label="WhatsApp">
          <MessageCircle size={20} />
          <span>WhatsApp</span>
        </a>
        <a href="mailto:sales@Nivara Developers.com" className="mobile-cta-action enquire" aria-label="Email Enquiry">
          <Mail size={20} />
          <span>Enquire</span>
        </a>
      </div>
    </>
  );
}
