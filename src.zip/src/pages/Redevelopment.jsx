import PageHero from '../components/PageHero';
import StatsSection from '../sections/Home/StatsSection';
import RedevelopmentProcess from '../sections/Home/RedevelopmentProcess';
import RedevelopmentFeatures from '../sections/Home/RedevelopmentFeatures';
import TestimonialsSection from '../sections/Home/TestimonialsSection';
import QuickInquiry from '../sections/Home/QuickInquiry';
import PremiumCTA from '../components/PremiumCTA';
import SEO from '../components/SEO';
import { useEffect } from 'react';

export default function Redevelopment() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="redevelopment-page">
      <SEO title="Society Redevelopment | Nivara Developers" description="Premium and transparent society redevelopment services by Nivara Developers." />
      <PageHero 
        title="Society Redevelopment" 
        image="https://images.unsplash.com/photo-1503387762-592deb58ef4e?q=80&w=2071&auto=format&fit=crop"
        breadcrumbItems={[{ label: 'Redevelopment' }]}
      />
      
      <section className="page-container py-16 text-center max-w-3xl mx-auto my-12" style={{maxWidth: '800px', margin: '4rem auto'}}>
        <h2 style={{fontSize: '2rem', marginBottom: '1rem'}}>Transforming Societies into Landmarks</h2>
        <p style={{color: 'var(--color-text-light)', lineHeight: 1.6, fontSize: '1.1rem'}}>
          With decades of expertise, Nivara Developers offers transparent, reliable, and premium society redevelopment services. We don't just rebuild structures; we upgrade lifestyles while preserving the soul of your community.
        </p>
      </section>

      <StatsSection />
      <RedevelopmentFeatures />
      <RedevelopmentProcess />
      <TestimonialsSection />
      
      <div id="enquiry">
        <QuickInquiry />
      </div>
      
      <PremiumCTA />
    </div>
  );
}
