import { useState } from 'react';
import { careersData as jobs } from '../../data/careers';
import Button from '../../components/Button';
import Modal from '../../components/Modal';
import { useToast } from '../../components/ToastProvider';
import { Briefcase, MapPin, Clock, ArrowLeft, ArrowRight, CheckCircle2 } from 'lucide-react';
import './JobListings.css';

export default function JobListings() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedJob, setSelectedJob] = useState(null);
  const [modalView, setModalView] = useState('details'); // 'details' or 'apply'
  
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', file: null, message: '' });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('idle');
  const { addToast } = useToast();

  const handleViewClick = (job) => {
    setSelectedJob(job);
    setModalView('details');
    setIsModalOpen(true);
    setStatus('idle');
  };

  const handleApplyClick = () => {
    setModalView('apply');
  };

  const handleBackToDetails = () => {
    setModalView('details');
  };

  const handleFileChange = (e) => {
    if(e.target.files.length > 0) {
      setFormData({...formData, file: e.target.files[0]});
      if (errors.file) setErrors({...errors, file: null});
    }
  };

  const handleChange = (e) => {
    setFormData({...formData, [e.target.name]: e.target.value});
    if (errors[e.target.name]) setErrors({...errors, [e.target.name]: null});
  };

  const validate = () => {
    const newErrors = {};
    if (formData.name.trim().length < 2) newErrors.name = 'Name must be at least 2 characters.';
    if (!/^[6-9]\d{9}$/.test(formData.phone)) newErrors.phone = 'Valid 10-digit Indian phone required.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) newErrors.email = 'Valid email required.';
    if (!formData.file) newErrors.file = 'Resume is required.';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;

    setStatus('loading');
    setTimeout(() => {
      setIsModalOpen(false);
      setStatus('idle');
      setFormData({ name: '', email: '', phone: '', file: null, message: '' });
      setErrors({});
      addToast({
        type: 'success',
        title: 'Application Submitted!',
        message: 'Thank you for applying. Our HR team will review your profile and get back to you shortly.'
      });
    }, 2000);
  };

  return (
    <section className="job-listings-section page-container">
      <div className="jobs-grid fade-up is-visible">
        {jobs.map((job) => (
          <div key={job.id} className="job-card">
            <div className="job-header">
              <h3>{job.title}</h3>
              <span className="job-department">{job.department}</span>
            </div>
            <div className="job-details">
              <span><MapPin size={16}/> {job.location}</span>
              <span><Clock size={16}/> {job.type}</span>
              <span><Briefcase size={16}/> {job.experience}</span>
            </div>
            <Button variant="outline-dark" onClick={() => handleViewClick(job)}>View Position</Button>
          </div>
        ))}
      </div>

      {selectedJob && (
        <Modal 
          isOpen={isModalOpen} 
          onClose={() => setIsModalOpen(false)} 
          title={modalView === 'details' ? selectedJob.title : `Apply for ${selectedJob.title}`}
        >
          {modalView === 'details' ? (
            <div className="job-modal-details">
              <div className="job-meta-tags">
                <span className="meta-tag"><MapPin size={14}/> {selectedJob.location}</span>
                <span className="meta-tag"><Clock size={14}/> {selectedJob.type}</span>
                <span className="meta-tag"><Briefcase size={14}/> {selectedJob.experience}</span>
              </div>
              
              <div className="job-section">
                <h4>Description</h4>
                <p>{selectedJob.description}</p>
              </div>
              
              <div className="job-section">
                <h4>Key Responsibilities</h4>
                <ul>
                  {selectedJob.responsibilities.map((req, i) => (
                    <li key={i}><CheckCircle2 size={16} className="text-accent" /> {req}</li>
                  ))}
                </ul>
              </div>

              <div className="job-section">
                <h4>Requirements</h4>
                <ul>
                  {selectedJob.requirements.map((req, i) => (
                    <li key={i}><CheckCircle2 size={16} className="text-accent" /> {req}</li>
                  ))}
                </ul>
              </div>

              <div className="job-section">
                <h4>Benefits</h4>
                <ul>
                  {selectedJob.benefits.map((req, i) => (
                    <li key={i}><CheckCircle2 size={16} className="text-accent" /> {req}</li>
                  ))}
                </ul>
              </div>

              <div className="modal-actions">
                <Button variant="primary" onClick={handleApplyClick} className="w-full">
                  Apply Now <ArrowRight size={16} className="ml-2 inline" />
                </Button>
              </div>
            </div>
          ) : (
            <div className="job-modal-apply">
              <button className="back-btn" onClick={handleBackToDetails}>
                <ArrowLeft size={16} /> Back to Job Details
              </button>
              <form className="application-form mt-4" onSubmit={handleSubmit} noValidate>
                <div className="form-group">
                  <label>Full Name *</label>
                  <input type="text" name="name" value={formData.name} onChange={handleChange} className={errors.name ? 'has-error' : ''} />
                  {errors.name && <span className="error-msg">{errors.name}</span>}
                </div>
                <div className="form-row">
                  <div className="form-group">
                    <label>Email Address *</label>
                    <input type="email" name="email" value={formData.email} onChange={handleChange} className={errors.email ? 'has-error' : ''} />
                    {errors.email && <span className="error-msg">{errors.email}</span>}
                  </div>
                  <div className="form-group">
                    <label>Phone Number *</label>
                    <input type="tel" name="phone" value={formData.phone} onChange={handleChange} className={errors.phone ? 'has-error' : ''} />
                    {errors.phone && <span className="error-msg">{errors.phone}</span>}
                  </div>
                </div>
                <div className="form-group file-upload">
                  <label>Resume (PDF/DOC) *</label>
                  <div className="file-input-wrapper">
                    <input type="file" accept=".pdf,.doc,.docx" onChange={handleFileChange} />
                    <div className={`file-input-custom ${errors.file ? 'has-error' : ''}`}>
                      {formData.file ? formData.file.name : 'Click to select or drag & drop file'}
                    </div>
                  </div>
                  {errors.file && <span className="error-msg">{errors.file}</span>}
                </div>
                <div className="form-group">
                  <label>Cover Letter / Message</label>
                  <textarea rows="4" name="message" value={formData.message} onChange={handleChange}></textarea>
                </div>
                <button type="submit" className="btn btn-primary w-full mt-2" disabled={status === 'loading'}>
                  {status === 'loading' ? 'Submitting...' : 'Submit Application'}
                </button>
              </form>
            </div>
          )}
        </Modal>
      )}
    </section>
  );
}
