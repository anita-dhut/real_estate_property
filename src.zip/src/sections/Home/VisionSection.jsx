import { useIntersectionObserver } from '../../hooks/useIntersectionObserver';
import './VisionSection.css';

export default function VisionSection() {
  const [ref, isVisible] = useIntersectionObserver();

  return (
    <section className="vision-section page-container" ref={ref}>
      <div className={`vision-grid ${isVisible ? 'is-visible' : ''}`}>
        
        <div className="vision-text-col fade-up">
          <span className="eyebrow">The Vision</span>
          <h2>"To develop a strong and lasting relationship"</h2>
          <p>
            By delivering exceptional homes that become the foundation of your family's memories. 
            Our vision is rooted in transparency, uncompromising quality, and an unwavering commitment to timelines.
          </p>
        </div>
        
        <div className="vision-img-col fade-in">
          <img src="https://images.unsplash.com/photo-1613545325278-f24b0cae1224?q=80&w=2070&auto=format&fit=crop" alt="Luxurious Living Space" loading="lazy" />
          <div className="vision-accent-box"></div>
        </div>

      </div>
    </section>
  );
}
