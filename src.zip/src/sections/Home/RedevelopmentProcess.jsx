import { useIntersectionObserver } from '../../hooks/useIntersectionObserver';
import SectionHeading from '../../components/SectionHeading';
import { Users, FileText, Handshake, CheckSquare, HardHat, Key } from 'lucide-react';
import './RedevelopmentProcess.css';

const steps = [
  { id: 1, title: 'Consultation', desc: 'Initial meeting to understand the society\'s requirements, feasibility, and vision for the new project.', icon: Users },
  { id: 2, title: 'Planning', desc: 'Architectural designs, 3D elevations, and finalization of amenities and specifications.', icon: FileText },
  { id: 3, title: 'Agreement', desc: 'Signing the formal Development Agreement (DA) with complete legal transparency.', icon: Handshake },
  { id: 4, title: 'Approvals', desc: 'Securing necessary sanctions from local authorities and MahaRERA registration.', icon: CheckSquare },
  { id: 5, title: 'Construction', desc: 'High-quality, time-bound construction using premium materials and safety standards.', icon: HardHat },
  { id: 6, title: 'Possession', desc: 'Handing over the keys to your brand new, luxurious, and upgraded homes.', icon: Key }
];

export default function RedevelopmentProcess() {
  const [ref, isVisible] = useIntersectionObserver();

  return (
    <section className="redev-process-section page-container" ref={ref}>
      <SectionHeading eyebrow="Our Workflow" title="The Redevelopment Process" />
      
      <div className={`timeline-container fade-up ${isVisible ? 'is-visible' : ''}`}>
        <div className="timeline-line"></div>
        <div className="timeline-steps">
          {steps.map((step) => {
            const Icon = step.icon;
            return (
              <div key={step.id} className="timeline-step">
                <div className="step-icon-wrapper">
                  <Icon size={24} className="step-icon" />
                  <div className="step-number-badge">0{step.id}</div>
                </div>
                <div className="step-details">
                  <h4>{step.title}</h4>
                  <p>{step.desc}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
