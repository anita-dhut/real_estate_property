import { useIntersectionObserver } from '../../hooks/useIntersectionObserver';
import './MissionSection.css';

export default function MissionSection() {
  const [ref, isVisible] = useIntersectionObserver();

  return (
    <section className="mission-section" ref={ref}>
      <div className={`mission-grid ${isVisible ? 'is-visible' : ''}`}>
        <div className="mission-image fade-in">
          <img src="https://images.unsplash.com/photo-1512917774080-9991f1c4c750?q=80&w=1500&auto=format&fit=crop" alt="Mission Architecture" loading="lazy" />
        </div>
        <div className="mission-content">
          <div className="mission-content-inner fade-up">
            <span className="eyebrow">Our Mission</span>
            <h2>To redefine urban living through architectural brilliance and sustainable design.</h2>
            <p>
              We aim to enrich lives by setting new standards for customer centricity, architectural design, quality, and safety. 
              Our mission is to continually innovate, ensuring that every square foot we build contributes to a better tomorrow.
            </p>
            <div className="decorative-element"></div>
          </div>
        </div>
      </div>
    </section>
  );
}
