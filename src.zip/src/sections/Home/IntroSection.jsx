import { useIntersectionObserver } from '../../hooks/useIntersectionObserver';
import Button from '../../components/Button';
import './IntroSection.css';

export default function IntroSection() {
  const [ref, isVisible] = useIntersectionObserver();

  return (
    <section className="intro-section page-container" ref={ref}>
      <div className={`intro-grid ${isVisible ? 'is-visible' : ''}`}>
        <div className="intro-content">
          <span className="eyebrow fade-up">About Nivara Developers</span>
          <h2 className="fade-up" style={{transitionDelay: '0.1s'}}>
            Building Trust,<br/>One Landmark at a Time.
          </h2>
          <p className="fade-up" style={{transitionDelay: '0.2s'}}>
            With over 40 years of profound legacy in the real estate sector, Nivara Developers Group stands as a beacon of architectural excellence, customer trust, and uncompromising quality. We don't just build homes; we curate lifestyles.
          </p>
          <div className="fade-up" style={{transitionDelay: '0.3s'}}>
            <Button to="/about" variant="secondary">Discover Our Story</Button>
          </div>
        </div>
        <div className="intro-image fade-in" style={{transitionDelay: '0.4s'}}>
          <img src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=2070&auto=format&fit=crop" alt="Modern Architecture" loading="lazy" />
        </div>
      </div>
    </section>
  );
}
