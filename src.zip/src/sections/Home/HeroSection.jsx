import { useState, useEffect } from 'react';
import { ChevronDown } from 'lucide-react';
import Button from '../../components/Button';
import './HeroSection.css';

export default function HeroSection() {
  const [offsetY, setOffsetY] = useState(0);

  useEffect(() => {
    const handleScroll = () => setOffsetY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <section className="hero-section">
      <div className="hero-bg">
        <img 
          src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?q=80&w=2075&auto=format&fit=crop" 
          alt="Luxury Real Estate" 
          style={{ transform: `translateY(${offsetY * 0.4}px) scale(1.05)` }}
        />
        <div className="hero-overlay"></div>
      </div>
      <div className="hero-content page-container">
        <span className="hero-eyebrow fade-up is-visible">ESTABLISHED 1980</span>
        <h1 className="hero-title fade-up is-visible" style={{transitionDelay: '0.1s'}}>
          Building Spaces.<br/>Creating Legacies.
        </h1>
        <p className="hero-subtitle fade-up is-visible" style={{transitionDelay: '0.2s'}}>
          Four decades of excellence in crafting premium residential and commercial landmarks that redefine luxury and trust.
        </p>
        <div className="hero-actions fade-up is-visible" style={{transitionDelay: '0.3s'}}>
          <Button to="/projects" variant="primary">Explore Portfolio</Button>
          <Button to="/contact" variant="outline-light">Get in Touch</Button>
        </div>
      </div>
      <div className="scroll-indicator fade-in">
        <span className="scroll-text">Scroll to explore</span>
        <ChevronDown size={24} className="bounce" />
      </div>
    </section>
  );
}
