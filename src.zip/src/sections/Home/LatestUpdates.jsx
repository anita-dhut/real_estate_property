import { Link } from 'react-router-dom';
import { allBlogs } from '../../data/blogs';
import { useIntersectionObserver } from '../../hooks/useIntersectionObserver';
import SectionHeading from '../../components/SectionHeading';
import { Calendar, ArrowRight } from 'lucide-react';
import './LatestUpdates.css';

export default function LatestUpdates() {
  const [ref, isVisible] = useIntersectionObserver();
  const latestBlogs = allBlogs.slice(0, 3);

  return (
    <section className="latest-updates-section page-container" ref={ref}>
      <SectionHeading eyebrow="News & Insights" title="Latest Updates" />
      
      <div className={`updates-grid fade-up ${isVisible ? 'is-visible' : ''}`}>
        {latestBlogs.map((blog) => (
          <div key={blog.id} className="update-card">
            <div className="update-img">
              <img src={blog.image} alt={blog.title} loading="lazy" />
              <span className="category-badge">{blog.category}</span>
            </div>
            <div className="update-content">
              <span className="update-date"><Calendar size={14}/> {blog.date}</span>
              <h3>{blog.title}</h3>
              <Link to={`/blogs/${blog.slug}`} className="read-more">
                Read Article <ArrowRight size={16} />
              </Link>
            </div>
          </div>
        ))}
      </div>
      
      <div className="text-center mt-12 fade-up is-visible" style={{transitionDelay: '0.2s'}}>
        <Link to="/blogs" className="btn btn-outline-dark">View All Updates</Link>
      </div>
    </section>
  );
}
