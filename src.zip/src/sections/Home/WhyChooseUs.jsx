import { useIntersectionObserver } from '../../hooks/useIntersectionObserver';
import { whyChooseUs } from '../../data/company';
import SectionHeading from '../../components/SectionHeading';
import * as Icons from 'lucide-react';
import './WhyChooseUs.css';

export default function WhyChooseUs() {
  const [ref, isVisible] = useIntersectionObserver();

  return (
    <section className="why-choose-us page-container" ref={ref}>
      <SectionHeading eyebrow="The Nivara Developers Advantage" title="Why Choose Us" />
      
      <div className={`features-grid fade-up ${isVisible ? 'is-visible' : ''}`}>
        {whyChooseUs.map((feature, idx) => {
          const Icon = Icons[feature.icon] || Icons.CheckCircle;
          return (
            <div key={feature.id} className="feature-card" style={{transitionDelay: `${idx * 0.1}s`}}>
              <div className="icon-wrapper">
                <Icon size={32} strokeWidth={1.5} />
              </div>
              <h3>{feature.title}</h3>
              <p>{feature.description}</p>
            </div>
          );
        })}
      </div>
    </section>
  );
}
