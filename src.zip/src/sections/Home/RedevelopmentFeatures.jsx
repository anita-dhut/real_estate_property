import { useIntersectionObserver } from '../../hooks/useIntersectionObserver';
import SectionHeading from '../../components/SectionHeading';
import { Leaf, Users, ShieldCheck, Cog } from 'lucide-react';
import './RedevelopmentFeatures.css';

export default function RedevelopmentFeatures() {
  const [ref, isVisible] = useIntersectionObserver();

  const features = [
    { icon: Users, title: 'Transforming Communities', desc: 'Upgrading lifestyles while preserving community bonds.' },
    { icon: Leaf, title: 'Sustainable Practices', desc: 'Implementing eco-friendly designs and energy-efficient systems.' },
    { icon: Cog, title: 'Custom Solutions', desc: 'Tailored architectural designs to meet specific society needs.' },
    { icon: ShieldCheck, title: 'Transparent Legalities', desc: 'Clear documentation and strict adherence to RERA guidelines.' }
  ];

  return (
    <section className="redev-features-section" ref={ref}>
      <div className="page-container">
        <SectionHeading eyebrow="Expertise" title="Why Choose Us for Redevelopment" align="center" />
        <div className={`features-grid fade-up ${isVisible ? 'is-visible' : ''}`}>
          {features.map((feature, idx) => {
            const Icon = feature.icon;
            return (
              <div key={idx} className="feature-card">
                <div className="icon-wrapper"><Icon size={32} /></div>
                <h3>{feature.title}</h3>
                <p>{feature.desc}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
