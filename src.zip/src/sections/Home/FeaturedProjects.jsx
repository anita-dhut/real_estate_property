import { useState } from 'react';
import { projects } from '../../data/constants';
import SectionHeading from '../../components/SectionHeading';
import Button from '../../components/Button';
import { useIntersectionObserver } from '../../hooks/useIntersectionObserver';
import { ArrowLeft, ArrowRight, MapPin } from 'lucide-react';
import { Link } from 'react-router-dom';
import './FeaturedProjects.css';

export default function FeaturedProjects() {
  const [ref, isVisible] = useIntersectionObserver({ threshold: 0.1 });
  const [currentIndex, setCurrentIndex] = useState(0);

  const featuredList = projects.slice(0, 5); // take first 5
  
  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % featuredList.length);
  };
  
  const prevSlide = () => {
    setCurrentIndex((prev) => (prev === 0 ? featuredList.length - 1 : prev - 1));
  };

  const currentProject = featuredList[currentIndex];

  return (
    <section className="featured-showcase page-container" ref={ref}>
      <div className="showcase-header">
        <SectionHeading 
          eyebrow="Our Portfolio"
          title="Featured Projects"
        />
        
        <div className="showcase-nav fade-up is-visible">
          <button onClick={prevSlide} className="showcase-nav-btn" aria-label="Previous Project">
            <ArrowLeft size={24} />
          </button>
          <span className="showcase-indicator">
            {String(currentIndex + 1).padStart(2, '0')} / {String(featuredList.length).padStart(2, '0')}
          </span>
          <button onClick={nextSlide} className="showcase-nav-btn" aria-label="Next Project">
            <ArrowRight size={24} />
          </button>
        </div>
      </div>

      <div className={`showcase-content fade-up ${isVisible ? 'is-visible' : ''}`}>
        <div className="showcase-main-img">
          <img key={currentProject.id} src={currentProject.image || currentProject.heroImage} alt={currentProject.title} loading="lazy" />
          <div className="showcase-overlay"></div>
          
          <div className="showcase-info">
            <div className="showcase-status">{currentProject.status}</div>
            <h3>{currentProject.title || currentProject.name}</h3>
            <div className="showcase-meta">
              <span><MapPin size={18}/> {currentProject.location}</span>
              <span>{currentProject.bhk}</span>
            </div>
            <Button to={`/projects/${currentProject.slug}`} variant="primary" className="mt-4">
              Explore Project
            </Button>
          </div>
        </div>
      </div>
      
      <div className="text-center mt-12 fade-up is-visible">
        <Button to="/projects" variant="outline-dark">
          View All Projects
        </Button>
      </div>
    </section>
  );
}
