import { useState } from 'react';
import { useIntersectionObserver } from '../../hooks/useIntersectionObserver';
import { testimonials } from '../../data/testimonials';
import SectionHeading from '../../components/SectionHeading';
import { ArrowLeft, ArrowRight } from 'lucide-react';
import './TestimonialsSection.css';

export default function TestimonialsSection() {
  const [ref, isVisible] = useIntersectionObserver();
  const [currentIndex, setCurrentIndex] = useState(0);

  const handlePrev = () => {
    setCurrentIndex(prev => (prev === 0 ? testimonials.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex(prev => (prev === testimonials.length - 1 ? 0 : prev + 1));
  };

  const handleKeyDown = (e, action) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      action();
    }
  };

  return (
    <section className="testimonials-section page-container" ref={ref}>
      <SectionHeading eyebrow="Client Voices" title="What Our Customers Say" />
      
      <div className={`testimonial-carousel fade-up ${isVisible ? 'is-visible' : ''}`}>
        
        <div className="testimonial-content-wrapper">
          <div className="quote-mark-large">"</div>
          
          <div className="testimonial-text-slider">
            <p className="testimonial-text">{testimonials[currentIndex].text}</p>
          </div>
          
          <div className="testimonial-author-row">
            <div className="author-info">
              <img src={testimonials[currentIndex].image} alt={testimonials[currentIndex].name} loading="lazy" className="author-img" />
              <div>
                <h4>{testimonials[currentIndex].name}</h4>
                <span>{testimonials[currentIndex].project}</span>
              </div>
            </div>
            
            <div className="carousel-controls">
              <div className="carousel-counter">
                0{currentIndex + 1} / 0{testimonials.length}
              </div>
              <div className="carousel-buttons">
                <button 
                  onClick={handlePrev} 
                  onKeyDown={(e) => handleKeyDown(e, handlePrev)}
                  aria-label="Previous Testimonial"
                >
                  <ArrowLeft size={20} />
                </button>
                <button 
                  onClick={handleNext} 
                  onKeyDown={(e) => handleKeyDown(e, handleNext)}
                  aria-label="Next Testimonial"
                >
                  <ArrowRight size={20} />
                </button>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
