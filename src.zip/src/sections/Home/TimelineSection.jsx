import { useIntersectionObserver } from '../../hooks/useIntersectionObserver';
import { timeline } from '../../data/company';
import SectionHeading from '../../components/SectionHeading';
import './TimelineSection.css';

export default function TimelineSection() {
  const [ref, isVisible] = useIntersectionObserver();

  return (
    <section className="timeline-section" ref={ref}>
      <div className="page-container">
        <SectionHeading eyebrow="Our Journey" title="Legacy of Excellence" />
        
        <div className={`timeline-container fade-up ${isVisible ? 'is-visible' : ''}`}>
          <div className="timeline-line"></div>
          
          <div className="timeline-items">
            {timeline.map((item, index) => (
              <div key={item.year} className="timeline-item">
                <div className="timeline-dot"></div>
                <div className="timeline-year">{item.year}</div>
                <div className="timeline-content">
                  <h3>{item.title}</h3>
                  <p>{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
}
